# 🚀 Trading Signal Bot - ZERO API KEYS VERSION

**For iPhone 17 | Discord Alerts | TradeLocker**

---

## ✅ What You Need (Only 1 Thing!)

| # | What | Status |
|---|------|--------|
| 1 | **Discord Webhook URL** | ✅ You already have this! |

That's it. No Alpaca. No OANDA. No signups.

---

## 📊 What Markets Does This Bot Analyze?

| TradeLocker Symbol | Market | Data Source |
|-------------------|--------|-------------|
| **SPX500** | S&P 500 Index | Yahoo Finance (15-min delayed) |
| **NAS100** | Nasdaq 100 Index | Yahoo Finance (15-min delayed) |
| **BTCUSD** | Bitcoin | Yahoo Finance (15-min delayed) |
| **EURUSD** | Euro vs Dollar | Yahoo Finance (15-min delayed) |
| **GBPUSD** | Pound vs Dollar | Yahoo Finance (15-min delayed) |
| **XAUUSD** | Gold | Yahoo Finance (15-min delayed) |

---

## ⚠️ Important: 15-Minute Delayed Data

**This bot uses Yahoo Finance, which is 15-minute delayed.**

**What this means:**
- The bot analyzes prices from 15 minutes ago
- Signals arrive 15 minutes after the setup actually formed
- **For 5-minute scalping:** This is too slow. You might miss the move.
- **For 15-minute+ trading:** This is usable. The patterns still form the same way.

**News alerts are NOT delayed** — they come in real-time from RSS feeds.

---

## 🔧 Setup (5 Minutes)

### Step 1: Create .env File

Create a file named `.env` in the bot folder with this inside:

```env
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_WEBHOOK_HERE
NOTIFIER=discord
```

(Replace with your actual Discord webhook URL)

### Step 2: Install & Run

```bash
pip install -r requirements.txt
python main.py
```

---

## ☁️ Deploy to Cloud (24/7)

### Render (Free)
1. Go to [render.com](https://render.com)
2. Create a **Background Worker**
3. Upload the bot files
4. Add environment variable: `DISCORD_WEBHOOK_URL`
5. Deploy

---

## 📰 News Alerts (Optional)

For real-time news alerts (Trump, Fed, war, etc.), sign up for free at [newsapi.org](https://newsapi.org) and add this to your `.env`:

```env
NEWS_API_KEY=your_newsapi_key_here
```

This is optional. The bot works without it.

---

## 🆘 Troubleshooting

**"No signals"**: Normal during quiet markets. Or check that it's market hours for stocks.
**"Discord not working"**: Check your webhook URL.
**"Bot crashes"**: Check that you created the `.env` file correctly.

---

## 🚀 Upgrade to Real-Time Later

When you're ready, add these for real-time data:
- **Alpaca** (free) → real-time SPX500, NAS100, BTC
- **OANDA** (free practice) → real-time EURUSD, GBPUSD, XAUUSD

Edit `bot/config.py` to add your API keys.

---

## 📄 License

Open-source educational software. Use at your own risk. Not financial advice.
