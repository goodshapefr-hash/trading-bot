"""
Trading Bot Configuration
=========================
ZERO API KEYS VERSION - Works immediately with Yahoo Finance
15-minute delayed data for all instruments.
Upgrade to real-time later by adding Alpaca/OANDA keys.
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ========================
# NOTIFICATION (ONLY THING YOU NEED)
# ========================
DISCORD_WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK_URL", "YOUR_DISCORD_WEBHOOK_URL_HERE")
NOTIFIER = os.getenv("NOTIFIER", "discord")

# ========================
# DATA SOURCE
# ========================
# Yahoo Finance = free, no signup, 15-min delayed
# Perfect for getting started. Upgrade later.
DATA_SOURCE = "yahoo"

# ========================
# ASSETS THE BOT MONITORS
# ========================
# ALL confirmed available on TradeLocker
# Yahoo Finance symbols for each:

ASSETS = {
    # ─── INDICES ───
    "SPX500": {
        "name": "S&P 500 Index (TradeLocker: SPX500)",
        "type": "index",
        "source": "yahoo",
        "yahoo_symbol": "^SPX",      # S&P 500 index on Yahoo
        "timeframe": "5m",
        "why": "The US stock market. Moves on Trump, Fed, earnings."
    },
    "NAS100": {
        "name": "Nasdaq 100 Index (TradeLocker: NAS100)",
        "type": "index",
        "source": "yahoo",
        "yahoo_symbol": "^NDX",      # Nasdaq 100 index on Yahoo
        "timeframe": "5m",
        "why": "Tech stocks. 2-3x more volatile than SPX500."
    },

    # ─── CRYPTO ───
    "BTCUSD": {
        "name": "Bitcoin (TradeLocker: BTCUSD)",
        "type": "crypto",
        "source": "yahoo",
        "yahoo_symbol": "BTC-USD",   # Bitcoin on Yahoo
        "timeframe": "5m",
        "why": "24/7 market. High volatility."
    },

    # ─── FOREX ───
    "EURUSD": {
        "name": "Euro vs Dollar (TradeLocker: EURUSD)",
        "type": "forex",
        "source": "yahoo",
        "yahoo_symbol": "EURUSD=X",  # EUR/USD on Yahoo
        "timeframe": "5m",
        "why": "Most liquid forex pair."
    },
    "GBPUSD": {
        "name": "Pound vs Dollar (TradeLocker: GBPUSD)",
        "type": "forex",
        "source": "yahoo",
        "yahoo_symbol": "GBPUSD=X",  # GBP/USD on Yahoo
        "timeframe": "5m",
        "why": "The Cable. Famous volatility."
    },

    # ─── METALS ───
    "XAUUSD": {
        "name": "Gold (TradeLocker: XAUUSD)",
        "type": "forex",
        "source": "yahoo",
        "yahoo_symbol": "GC=F",      # Gold futures on Yahoo
        "timeframe": "5m",
        "why": "Safe haven. Explodes on fear/war/inflation."
    },
}

# ========================
# NEWS SETTINGS (FREE - NewsAPI)
# ========================
# Optional but recommended. 100 free requests/day.
# Sign up at newsapi.org if you want real-time news alerts.
# Leave blank if you don't want news.
NEWS_API_KEY = os.getenv("NEWS_API_KEY", "")

NEWS_SOURCES = [
    "reuters.com",
    "bloomberg.com",
    "cnbc.com",
    "forexlive.com",
    "apnews.com"
]

HIGH_IMPACT_KEYWORDS = [
    "trump", "biden", "fed", "federal reserve", "interest rate",
    "tariff", "war", "sanctions", "inflation", "recession",
    "crash", "rally", "bull", "bear", "nuclear", "opec",
    "gold", "spx", "s&p", "nasdaq",
    "bitcoin", "btc", "crypto",
    "euro", "eurusd", "gbp", "pound",
    "ecb", "bank of england", "boe"
]

SENTIMENT_THRESHOLD = 0.6

# ========================
# SIGNAL SETTINGS
# ========================
MIN_SIGNAL_STRENGTH = 65
EMA_FAST = 9
EMA_SLOW = 21
RSI_PERIOD = 14
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
BB_PERIOD = 20
BB_STD = 2.0
ATR_PERIOD = 14

# Risk Settings
RISK_PER_TRADE = 0.02
ATR_MULTIPLIER_SL = 1.5
ATR_MULTIPLIER_TP = 3.0
