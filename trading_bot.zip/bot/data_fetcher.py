"""
Data Fetcher Module - Yahoo Finance Only Version
Zero API keys needed. 15-minute delayed data.
"""
import pandas as pd
import yfinance as yf
from typing import Dict

class DataFetcher:
    def __init__(self, config):
        self.config = config

    def fetch(self, symbol: str, source: str = "yahoo", yahoo_symbol: str = None) -> pd.DataFrame:
        """Fetch from Yahoo Finance (15-min delayed, free, no signup)"""
        try:
            # Use the Yahoo symbol mapping if provided
            fetch_symbol = yahoo_symbol if yahoo_symbol else symbol

            ticker = yf.Ticker(fetch_symbol)
            df = ticker.history(interval="5m", period="5d")

            if df.empty:
                print(f"No data returned for {symbol} ({fetch_symbol})")
                return pd.DataFrame()

            df.reset_index(inplace=True)
            if 'Datetime' in df.columns:
                df.rename(columns={'Datetime': 'timestamp'}, inplace=True)
            else:
                df.rename(columns={'Date': 'timestamp'}, inplace=True)

            print(f"[{pd.Timestamp.now()}] Fetched {len(df)} bars for {symbol} ({fetch_symbol})")
            return df

        except Exception as e:
            print(f"Yahoo Finance error for {symbol} ({fetch_symbol}): {e}")
            return pd.DataFrame()
