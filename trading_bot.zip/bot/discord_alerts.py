"""
Discord Webhook Alert Module
"""
import requests
from typing import Dict
from datetime import datetime

class DiscordAlerter:
    def __init__(self, config):
        self.config = config
        self.webhook_url = getattr(config, 'DISCORD_WEBHOOK_URL', '')

    def _send_embed(self, title: str, description: str, color: int, fields: list = None):
        if not self.webhook_url or self.webhook_url == "YOUR_DISCORD_WEBHOOK_URL_HERE":
            print(f"[DISCORD NOT CONFIGURED] {title}")
            print(description)
            return

        embed = {
            "title": title,
            "description": description,
            "color": color,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "footer": {"text": "Trading Bot v1.0 | Not Financial Advice | 15m Delayed Data"}
        }

        if fields:
            embed["fields"] = fields

        payload = {"embeds": [embed]}

        try:
            response = requests.post(
                self.webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            if response.status_code not in [200, 204]:
                print(f"Discord webhook error: {response.status_code}")
        except Exception as e:
            print(f"Discord send error: {e}")

    def send_signal(self, signal: Dict):
        color = 0x00FF00 if "BUY" in signal["signal"] else 0xFF0000 if "SELL" in signal["signal"] else 0x808080

        strength_bar = "█" * (signal["strength"] // 10) + "░" * (10 - signal["strength"] // 10)
        market_name = signal.get("market_name", signal["symbol"])
        why = signal.get("why", "")
        delay_warning = signal.get("data_delay_warning", "")

        description = f"""**TradeLocker Symbol:** {signal['symbol']}
**Market:** {market_name}
**Why scalp this?** {why}
**Signal:** {signal['signal']}
**Strength:** `{signal['strength']}/100` {strength_bar}
**Price:** `${signal['price']}`
**Time:** `{signal['timestamp']}`
**Direction:** {signal['direction']}

{delay_warning}
"""

        fields = [
            {
                "name": "📊 Indicators",
                "value": f"```
RSI:        {signal['indicators'].get('RSI', 'N/A')}
"
                        f"EMA 9:      {signal['indicators'].get('EMA_9', 'N/A')}
"
                        f"EMA 21:     {signal['indicators'].get('EMA_21', 'N/A')}
"
                        f"MACD Hist:  {signal['indicators'].get('MACD_Hist', 'N/A')}
"
                        f"BB Position: {signal['indicators'].get('BB_Position', 'N/A')}
"
                        f"ATR:        {signal['indicators'].get('ATR', 'N/A')}
```",
                "inline": True
            },
            {
                "name": "🎯 Levels",
                "value": f"```
Support:    {', '.join(map(str, signal['levels']['support']))}
"
                        f"Resistance: {', '.join(map(str, signal['levels']['resistance']))}
```",
                "inline": True
            },
            {
                "name": "🛡️ Risk Management",
                "value": f"```
Stop Loss:   ${signal['risk_management'].get('stop_loss', 'N/A')}
"
                        f"Take Profit: ${signal['risk_management'].get('take_profit', 'N/A')}
"
                        f"R:R Ratio:   {signal['risk_management'].get('risk_reward', 'N/A')}
"
                        f"Position:    {signal['risk_management'].get('suggested_position', '')}
```",
                "inline": False
            },
            {
                "name": "📝 Setup Reasons",
                "value": "
".join([f"• {r}" for r in signal["reasons"]]) or "N/A",
                "inline": False
            }
        ]

        self._send_embed(
            title=f"📈 {signal['symbol']} Signal Alert",
            description=description,
            color=color,
            fields=fields
        )

    def send_news_alert(self, alert: Dict):
        color = 0x00FF00 if alert["direction"] == "BULLISH" else 0xFF0000
        emoji = "🚀" if alert["direction"] == "BULLISH" else "🔻"

        description = f"""{emoji} **{alert['impact']}** {emoji}

**Direction:** `{alert['direction']}`
**Sentiment Score:** `{alert['sentiment_score']}`
**Keywords:** `{', '.join(alert['keywords'])}`

**Headline:**
{alert['title']}

**Source:** {alert['source']}
**URL:** {alert['url']}

⏰ Detected at: `{alert['timestamp'].strftime('%H:%M:%S')}`

⚠️ Check charts immediately for entry/exit opportunities.
"""

        self._send_embed(
            title=f"📰 Breaking News Alert",
            description=description,
            color=color
        )

    def send_status(self, message: str):
        self._send_embed(
            title="🤖 Bot Status Update",
            description=message,
            color=0x3498DB
        )
