"""
News Sentinel Module
Monitors political/economic news for sudden market moves
"""
import requests
import feedparser
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

class NewsMonitor:
    def __init__(self, config):
        self.config = config
        self.analyzer = SentimentIntensityAnalyzer()
        self.seen_articles = set()
        self.last_check = datetime.now() - timedelta(hours=1)

    def fetch_newsapi(self) -> List[Dict]:
        """Fetch from NewsAPI.org (free tier: 100 req/day)"""
        if not self.config.NEWS_API_KEY:
            return []

        try:
            url = "https://newsapi.org/v2/everything"
            query = " OR ".join([f'"{k}"' for k in self.config.HIGH_IMPACT_KEYWORDS[:10]])

            params = {
                "q": query,
                "from": (datetime.now() - timedelta(hours=6)).strftime("%Y-%m-%dT%H:%M:%S"),
                "sortBy": "publishedAt",
                "language": "en",
                "pageSize": 20,
                "apiKey": self.config.NEWS_API_KEY
            }

            response = requests.get(url, params=params, timeout=10)
            data = response.json()

            articles = []
            if data.get("status") == "ok":
                for article in data.get("articles", []):
                    articles.append({
                        "title": article.get("title", ""),
                        "source": article.get("source", {}).get("name", ""),
                        "url": article.get("url", ""),
                        "published": article.get("publishedAt", ""),
                        "content": article.get("description", "") + " " + article.get("content", "")
                    })
            return articles
        except Exception as e:
            print(f"NewsAPI error: {e}")
            return []

    def fetch_rss(self) -> List[Dict]:
        """Fetch from RSS feeds (free, no API key needed)"""
        articles = []
        rss_feeds = [
            "https://www.forexlive.com/feed",
            "https://feeds.reuters.com/reuters/businessnews",
            "https://www.cnbc.com/id/100003114/device/rss/rss.html",
            "https://apnews.com/rss",
            "https://feeds.bbci.co.uk/news/business/rss.xml"
        ]

        for feed_url in rss_feeds:
            try:
                feed = feedparser.parse(feed_url)
                for entry in feed.entries[:5]:
                    articles.append({
                        "title": entry.get("title", ""),
                        "source": feed_url.split("/")[2],
                        "url": entry.get("link", ""),
                        "published": entry.get("published", ""),
                        "content": entry.get("summary", "")
                    })
            except Exception as e:
                continue

        return articles

    def analyze_sentiment(self, text: str) -> Dict:
        """Analyze sentiment using VADER"""
        scores = self.analyzer.polarity_scores(text)
        return {
            "compound": scores['compound'],
            "positive": scores['pos'],
            "negative": scores['neg'],
            "neutral": scores['neu']
        }

    def detect_market_impact(self, article: Dict) -> Optional[Dict]:
        """
        Detect if article could cause sudden market move
        Returns alert dict if high impact, None otherwise
        """
        text = (article["title"] + " " + article["content"]).lower()

        # Check for high impact keywords
        matched_keywords = [k for k in self.config.HIGH_IMPACT_KEYWORDS if k.lower() in text]

        if not matched_keywords:
            return None

        sentiment = self.analyze_sentiment(text)

        # Determine if this is a market-moving alert
        if abs(sentiment["compound"]) >= self.config.SENTIMENT_THRESHOLD:
            if sentiment["compound"] > 0:
                direction = "BULLISH"
                impact = "🚀 SUDDEN BULL ALERT"
            else:
                direction = "BEARISH"
                impact = "🔻 SUDDEN CRASH ALERT"

            return {
                "type": "NEWS_ALERT",
                "impact": impact,
                "direction": direction,
                "sentiment_score": round(sentiment["compound"], 3),
                "title": article["title"],
                "source": article["source"],
                "url": article["url"],
                "keywords": matched_keywords,
                "timestamp": datetime.now()
            }

        return None

    def scan(self) -> List[Dict]:
        """Full scan - returns list of high-impact alerts"""
        alerts = []

        # Try NewsAPI first, fall back to RSS
        articles = self.fetch_newsapi()
        if not articles:
            articles = self.fetch_rss()

        for article in articles:
            # Deduplicate
            article_id = article["title"] + article.get("url", "")
            if article_id in self.seen_articles:
                continue
            self.seen_articles.add(article_id)

            # Check for market impact
            alert = self.detect_market_impact(article)
            if alert:
                alerts.append(alert)

        # Keep seen_articles from growing too large
        if len(self.seen_articles) > 1000:
            self.seen_articles = set(list(self.seen_articles)[-500:])

        self.last_check = datetime.now()
        return alerts
