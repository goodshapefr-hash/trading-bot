"""
Technical Analysis Engine
Multi-indicator confluence scoring for 5-15 min setups
"""
import pandas as pd
import numpy as np
from typing import Dict, Tuple, List

class TechnicalAnalyzer:
    def __init__(self, config):
        self.config = config

    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate all technical indicators"""
        df = df.copy()

        # EMAs
        df[f'EMA_{self.config.EMA_FAST}'] = df['Close'].ewm(span=self.config.EMA_FAST, adjust=False).mean()
        df[f'EMA_{self.config.EMA_SLOW}'] = df['Close'].ewm(span=self.config.EMA_SLOW, adjust=False).mean()

        # RSI
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=self.config.RSI_PERIOD).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=self.config.RSI_PERIOD).mean()
        rs = gain / loss
        df['RSI'] = 100 - (100 / (1 + rs))

        # MACD
        ema_fast = df['Close'].ewm(span=self.config.MACD_FAST, adjust=False).mean()
        ema_slow = df['Close'].ewm(span=self.config.MACD_SLOW, adjust=False).mean()
        df['MACD'] = ema_fast - ema_slow
        df['MACD_Signal'] = df['MACD'].ewm(span=self.config.MACD_SIGNAL, adjust=False).mean()
        df['MACD_Hist'] = df['MACD'] - df['MACD_Signal']

        # Bollinger Bands
        df['BB_Middle'] = df['Close'].rolling(window=self.config.BB_PERIOD).mean()
        bb_std = df['Close'].rolling(window=self.config.BB_PERIOD).std()
        df['BB_Upper'] = df['BB_Middle'] + (self.config.BB_STD * bb_std)
        df['BB_Lower'] = df['BB_Middle'] - (self.config.BB_STD * bb_std)
        df['BB_Width'] = df['BB_Upper'] - df['BB_Lower']
        df['BB_Position'] = (df['Close'] - df['BB_Lower']) / (df['BB_Upper'] - df['BB_Lower'])

        # ATR (Average True Range)
        high_low = df['High'] - df['Low']
        high_close = np.abs(df['High'] - df['Close'].shift())
        low_close = np.abs(df['Low'] - df['Close'].shift())
        ranges = pd.concat([high_low, high_close, low_close], axis=1)
        true_range = np.max(ranges, axis=1)
        df['ATR'] = true_range.rolling(window=self.config.ATR_PERIOD).mean()

        # Volume SMA (if volume exists)
        if 'Volume' in df.columns:
            df['Volume_SMA'] = df['Volume'].rolling(window=20).mean()

        # Support/Resistance (simple pivot method)
        df['Pivot_High'] = df['High'][(df['High'].shift(1) < df['High']) & 
                                       (df['High'].shift(-1) < df['High'])]
        df['Pivot_Low'] = df['Low'][(df['Low'].shift(1) > df['Low']) & 
                                     (df['Low'].shift(-1) > df['Low'])]

        return df

    def find_nearest_levels(self, df: pd.DataFrame, current_price: float, n: int = 3) -> Tuple[List[float], List[float]]:
        """Find nearest support and resistance levels"""
        highs = df['Pivot_High'].dropna().tail(20).values
        lows = df['Pivot_Low'].dropna().tail(20).values

        # Group close levels
        resistance = sorted([h for h in highs if h > current_price])[:n]
        support = sorted([l for l in lows if l < current_price], reverse=True)[:n]

        return support, resistance

    def generate_signal(self, df: pd.DataFrame, symbol: str) -> Dict:
        """
        Generate trading signal with confluence scoring
        Returns: dict with signal details
        """
        if len(df) < 50:
            return {"signal": "NONE", "strength": 0, "reason": "Insufficient data"}

        df = self.calculate_indicators(df)
        last = df.iloc[-1]
        prev = df.iloc[-2]
        current_price = last['Close']

        # Initialize score components
        score = 0
        reasons = []
        alerts = []

        # 1. EMA TREND (0-25 points)
        ema_fast = last[f'EMA_{self.config.EMA_FAST}']
        ema_slow = last[f'EMA_{self.config.EMA_SLOW}']

        if ema_fast > ema_slow and prev[f'EMA_{self.config.EMA_FAST}'] <= prev[f'EMA_{self.config.EMA_SLOW}']:
            score += 25
            reasons.append("✅ EMA Golden Cross (9/21)")
        elif ema_fast < ema_slow and prev[f'EMA_{self.config.EMA_FAST}'] >= prev[f'EMA_{self.config.EMA_SLOW}']:
            score -= 25
            reasons.append("❌ EMA Death Cross (9/21)")
        elif ema_fast > ema_slow:
            score += 10
            reasons.append("📈 EMA Bullish alignment")
        else:
            score -= 10
            reasons.append("📉 EMA Bearish alignment")

        # 2. RSI MOMENTUM (0-20 points)
        rsi = last['RSI']
        if rsi < self.config.RSI_OVERSOLD and prev['RSI'] >= self.config.RSI_OVERSOLD:
            score += 20
            reasons.append(f"✅ RSI Oversold bounce ({rsi:.1f})")
        elif rsi > self.config.RSI_OVERBOUGHT and prev['RSI'] <= self.config.RSI_OVERBOUGHT:
            score -= 20
            reasons.append(f"❌ RSI Overbought rejection ({rsi:.1f})")
        elif rsi < 40:
            score += 10
            reasons.append(f"📈 RSI Bullish room ({rsi:.1f})")
        elif rsi > 60:
            score -= 10
            reasons.append(f"📉 RSI Bearish room ({rsi:.1f})")

        # 3. MACD MOMENTUM (0-20 points)
        macd_hist = last['MACD_Hist']
        prev_hist = prev['MACD_Hist']

        if macd_hist > 0 and prev_hist <= 0:
            score += 20
            reasons.append("✅ MACD Histogram flip bullish")
        elif macd_hist < 0 and prev_hist >= 0:
            score -= 20
            reasons.append("❌ MACD Histogram flip bearish")
        elif macd_hist > 0:
            score += 10
            reasons.append("📈 MACD Bullish momentum")
        else:
            score -= 10
            reasons.append("📉 MACD Bearish momentum")

        # 4. BOLLINGER BANDS (0-15 points)
        bb_pos = last['BB_Position']
        if bb_pos < 0.1 and prev['BB_Position'] >= 0.1:
            score += 15
            reasons.append("✅ Price at Lower BB (oversold)")
        elif bb_pos > 0.9 and prev['BB_Position'] <= 0.9:
            score -= 15
            reasons.append("❌ Price at Upper BB (overbought)")
        elif bb_pos < 0.3:
            score += 5
            reasons.append("📈 Price near Lower BB")
        elif bb_pos > 0.7:
            score -= 5
            reasons.append("📉 Price near Upper BB")

        # 5. VOLUME CONFIRMATION (0-10 points)
        if 'Volume' in df.columns and 'Volume_SMA' in df.columns:
            if last['Volume'] > last['Volume_SMA'] * 1.5:
                if score > 0:
                    score += 10
                    reasons.append("✅ High volume confirming bullish")
                elif score < 0:
                    score -= 10
                    reasons.append("✅ High volume confirming bearish")

        # 6. PRICE ACTION / SUPPORT/RESISTANCE (0-10 points)
        support, resistance = self.find_nearest_levels(df, current_price)

        if support and current_price < support[0] * 1.002:  # Near support
            if score > 0:
                score += 10
                reasons.append(f"✅ Bouncing off support ${support[0]:.2f}")

        if resistance and current_price > resistance[0] * 0.998:  # Near resistance
            if score < 0:
                score -= 10
                reasons.append(f"❌ Rejecting at resistance ${resistance[0]:.2f}")

        # Determine signal type
        if score >= self.config.MIN_SIGNAL_STRENGTH:
            signal_type = "STRONG_BUY"
        elif score >= 45:
            signal_type = "BUY"
        elif score <= -self.config.MIN_SIGNAL_STRENGTH:
            signal_type = "STRONG_SELL"
        elif score <= -45:
            signal_type = "SELL"
        else:
            signal_type = "NEUTRAL"

        # Calculate Stop Loss and Take Profit using ATR
        atr = last['ATR']
        if pd.notna(atr) and atr > 0:
            if "BUY" in signal_type:
                stop_loss = current_price - (atr * self.config.ATR_MULTIPLIER_SL)
                take_profit = current_price + (atr * self.config.ATR_MULTIPLIER_TP)
            elif "SELL" in signal_type:
                stop_loss = current_price + (atr * self.config.ATR_MULTIPLIER_SL)
                take_profit = current_price - (atr * self.config.ATR_MULTIPLIER_TP)
            else:
                stop_loss = None
                take_profit = None
        else:
            stop_loss = None
            take_profit = None

        # Risk:Reward ratio
        if stop_loss and take_profit:
            risk = abs(current_price - stop_loss)
            reward = abs(take_profit - current_price)
            rr_ratio = reward / risk if risk > 0 else 0
        else:
            rr_ratio = 0

        return {
            "symbol": symbol,
            "signal": signal_type,
            "strength": abs(score),
            "direction": "BULLISH" if score > 0 else "BEARISH" if score < 0 else "NEUTRAL",
            "price": current_price,
            "timestamp": last['timestamp'] if 'timestamp' in last else pd.Timestamp.now(),
            "indicators": {
                "RSI": round(rsi, 2) if pd.notna(rsi) else None,
                "EMA_9": round(ema_fast, 2) if pd.notna(ema_fast) else None,
                "EMA_21": round(ema_slow, 2) if pd.notna(ema_slow) else None,
                "MACD_Hist": round(macd_hist, 4) if pd.notna(macd_hist) else None,
                "BB_Position": round(bb_pos, 2) if pd.notna(bb_pos) else None,
                "ATR": round(atr, 2) if pd.notna(atr) else None
            },
            "levels": {
                "support": [round(s, 2) for s in support[:2]],
                "resistance": [round(r, 2) for r in resistance[:2]]
            },
            "risk_management": {
                "stop_loss": round(stop_loss, 2) if stop_loss else None,
                "take_profit": round(take_profit, 2) if take_profit else None,
                "risk_reward": round(rr_ratio, 2) if rr_ratio else None,
                "suggested_position": f"Risk {self.config.RISK_PER_TRADE*100}% of account"
            },
            "reasons": reasons,
            "raw_score": score
        }
