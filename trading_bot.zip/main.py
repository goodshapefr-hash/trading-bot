#!/usr/bin/env python3
"""
24/7 Trading Signal Bot - ZERO API KEYS VERSION
Uses Yahoo Finance (free, 15-min delayed)
Perfect for getting started. Upgrade to real-time later.

SETUP:
1. pip install -r requirements.txt
2. Set DISCORD_WEBHOOK_URL in .env file
3. python main.py
"""
import asyncio
import schedule
from datetime import datetime
from typing import Dict

from bot.config import Config
from bot.data_fetcher import DataFetcher
from bot.technical_analysis import TechnicalAnalyzer
from bot.news_monitor import NewsMonitor
from bot.discord_alerts import DiscordAlerter

class TradingBot:
    def __init__(self):
        self.config = Config()
        self.fetcher = DataFetcher(self.config)
        self.analyzer = TechnicalAnalyzer(self.config)
        self.news = NewsMonitor(self.config)
        self.alerter = DiscordAlerter(self.config)
        self.last_signals = {}

    async def analyze_asset(self, symbol: str, settings: Dict):
        """Analyze a single asset and send alert if signal is strong"""
        try:
            yahoo_sym = settings.get("yahoo_symbol", symbol)
            df = self.fetcher.fetch(symbol, yahoo_symbol=yahoo_sym)

            if df.empty or len(df) < 50:
                return

            signal = self.analyzer.generate_signal(df, symbol)
            signal["market_name"] = settings.get("name", symbol)
            signal["why"] = settings.get("why", "")
            signal["data_delay_warning"] = "⚠️ 15-min delayed data"

            if signal["signal"] in ["STRONG_BUY", "STRONG_SELL", "BUY", "SELL"]:
                signal_key = f"{symbol}_{signal['signal']}"

                last = self.last_signals.get(signal_key, 0)
                if signal["strength"] >= last + 10 or signal["strength"] >= self.config.MIN_SIGNAL_STRENGTH:
                    self.last_signals[signal_key] = signal["strength"]
                    self.alerter.send_signal(signal)
                    print(f"[{datetime.now()}] ALERT: {symbol} {signal['signal']} (Strength: {signal['strength']})")

            elif signal["signal"] == "NEUTRAL":
                for key in list(self.last_signals.keys()):
                    if key.startswith(symbol):
                        del self.last_signals[key]

        except Exception as e:
            print(f"Error analyzing {symbol}: {e}")

    async def check_news(self):
        """Check for breaking news"""
        try:
            alerts = self.news.scan()
            for alert in alerts:
                self.alerter.send_news_alert(alert)
                print(f"[{datetime.now()}] NEWS ALERT: {alert['title'][:50]}...")
        except Exception as e:
            print(f"News check error: {e}")

    async def run_analysis_cycle(self):
        """One full analysis cycle"""
        tasks = []
        for symbol, settings in self.config.ASSETS.items():
            tasks.append(self.analyze_asset(symbol, settings))

        await asyncio.gather(*tasks, return_exceptions=True)

    async def run(self):
        """Main loop"""
        markets = []
        for sym, sett in self.config.ASSETS.items():
            markets.append(f"• {sym}: {sett['name']}")

        self.alerter.send_status(
            "🤖 Bot Started (Zero API Keys Version)\n"
            "Data: Yahoo Finance (15-min delayed)\n"
            "Instruments:\n" + "\n".join(markets) + "\n"
            "Timeframe: 5-15 min\n"
            "News scanning: ACTIVE\n"
            "⚠️ Signals are 15-min delayed. Use for 15m+ timeframe."
        )

        print("=" * 60)
        print("TRADING BOT STARTED - ZERO API KEYS VERSION")
        print("Data: Yahoo Finance (15-min delayed)")
        print("Instruments:")
        for line in markets:
            print(f"  {line}")
        print(f"Timeframe: 5-15 min")
        print("⚠️  Signals are 15-min delayed. Use for 15m+ timeframe.")
        print("Press Ctrl+C to stop")
        print("=" * 60)

        # Run every 5 minutes
        schedule.every(5).minutes.do(lambda: asyncio.create_task(self.run_analysis_cycle()))
        schedule.every(2).minutes.do(lambda: asyncio.create_task(self.check_news()))

        # Run immediately on start
        await self.run_analysis_cycle()
        await self.check_news()

        while True:
            schedule.run_pending()
            await asyncio.sleep(1)

if __name__ == "__main__":
    bot = TradingBot()
    asyncio.run(bot.run())
